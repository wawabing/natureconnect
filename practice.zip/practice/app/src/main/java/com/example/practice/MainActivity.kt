package com.example.practice


import androidx.compose.foundation.shape.RoundedCornerShape
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.practice.ui.theme.PracticeTheme
import androidx.compose.foundation.border


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PracticeTheme {
                Scaffold(
                    bottomBar = {
                        BottomAppBar(
                            containerColor = Color(0xFF00C892) // Green bottom bar 🌿
                        ) {
                            BottomBarContent()
                        }
                    },
                    content = { innerPadding ->
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFFFFFFFF)) // White background 🎨
                                .padding(innerPadding),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Greeting("Owen") // Top greeting text
                            Spacer(modifier = Modifier.height(40.dp)) // Space between text and grid
                            PlantGrid() // Grid of plant circles
                            Spacer(modifier = Modifier.height(40.dp)) // Space between grid and fun fact
                            FunFact(modifier = Modifier.weight(1f)) // Expands to fill remaining space
                            Spacer(modifier = Modifier.height(10.dp)) // Space between fact and bottom bar
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun PlantGrid() {
    val userPlants = listOf("Monstera", "Aloe", "Bonsai") // Example: User has 2 plants

    // Ensure exactly 4 slots (fill remaining with "+")
    val plantSlots = userPlants.take(4) + List(4 - userPlants.size) { "+" }

    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        for (row in 0..1) { // Creates 2 rows
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                for (col in 0..1) { // Creates 2 columns per row
                    val index = row * 2 + col
                    PlantCircle(plantName = plantSlots[index])
                }
            }
            Spacer(modifier = Modifier.height(30.dp)) // Space between rows
        }
    }
}


@Composable
fun PlantCircle(plantName: String?) {
    Box(
        modifier = Modifier
            .size(120.dp) // Circle size
            .border(width = 1.dp, color = Color(0xFF145A32), shape = CircleShape) // Dark green border
            .background(Color(0xFFE9F8F6), shape = CircleShape)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = plantName ?: "+",
            fontSize = if (plantName == "+") 48.sp else 16.sp, // Larger "+" text
            textAlign = TextAlign.Center,
            color = if (plantName == "+") Color(0xFF00C892) else Color.Black
        )
    }
}



@Composable
fun FunFact(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .fillMaxHeight() // Expands dynamically
            .padding(horizontal = 16.dp, vertical = 10.dp) // Add margins
            .background(Color(0x8074E0C4), shape = RoundedCornerShape(12.dp)), // Rounded box
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.padding(16.dp), // Padding inside the box
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Title: "Fun Fact:"
            Text(
                text = "Fun Fact:",
                fontSize = 22.sp,
                color = Color(0xFF145A32), // Dark green title
                style = MaterialTheme.typography.headlineSmall
            )

            Spacer(modifier = Modifier.height(8.dp)) // Space between title and fact

            // Actual fun fact
            Text(
                text = "Monstera deliciosa, also known as the Swiss Cheese Plant, develops natural holes in its leaves to withstand heavy rain and strong winds in tropical rainforests!",
                textAlign = TextAlign.Center,
                fontSize = 16.sp,
                color = Color.Black
            )
        }
    }
}



@Composable
fun BottomBarContent() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        repeat(4) { // Creates 4 white rounded boxes
            Box(
                modifier = Modifier
                    .size(60.dp) // Adjust the box size
                    .background(Color.White, shape = RoundedCornerShape(12.dp)) // Rounded corners
            )
        }
    }
}

@Composable
fun Greeting(name: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 60.dp), // Adjust top padding as needed
        contentAlignment = Alignment.TopCenter
    ) {
        Text(
            text = "Hello $name!\n\n Here are your plants...",
            textAlign = TextAlign.Center
        )
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    PracticeTheme {
        Greeting("Android")
    }
}
